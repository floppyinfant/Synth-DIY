var class_cap_poll =
[
    [ "CapPoll", "class_cap_poll.html#a4f691e78391a306d9ee89cdb1026096f", null ],
    [ "next", "class_cap_poll.html#a894e8abbabff197f4d17106455fef718", null ]
];